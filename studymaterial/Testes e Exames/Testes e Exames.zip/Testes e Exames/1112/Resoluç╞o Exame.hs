{-
Exercicio 1 
a) head (reverse [1,2,3]) = 3
b) map (*2) [0,1,2] = [0,2,4]
c) filter (>0) [2,-1,1,0,-2] = [2,1]
d) sum [x*y | (x,y)<-zip [1,2] [-2,2]] = -2
e) foldr (\x y->2*x+y) 0 [1,2,3] = 12
f) [[1],[2,3],[4,5,6]] = [[Int]]
g) \xs->filter (/=' ') xs = [Char] -> [Char]
h) a -> [a] -> Bool
-}

--Exercicio 2 
duplicar :: String -> String
duplicar "" = ""
duplicar (x:xs) | ((x =='a') || (x=='e') || (x=='i') || (x=='o') || (x=='u')) = x:x:(duplicar xs)
	            | otherwise = x:(duplicar xs)


--Exercicio 3 
type Ponto = (Float, Float)

dist :: Ponto -> Ponto -> Float
dist (x1,y1) (x2,y2) = sqrt(((x1-x2)^2) + ((y1-y2)^2))

--Exercicio 4 

data Arv a = Vazia | No a (Arv a) (Arv a)

insert :: Ord a => a -> Arv a -> Arv a 
insert x Vazia = No x Vazia Vazia
insert x (No y esq dir) | x == y = No y esq dir
	                    | x > y = No y dir (insert x dir)
	                    | x < y = No y (insert x esq) dir

--Exercicio 5





-----------------------
Queremos demonstrar que : sum (xs ++ ys) = sum xs + sum ys 

sum [] = 0 
sum (x:xs) = x+sum xs
Caso base: 
sum([] ++ ys) = sum ys = 0 + sum ys = sum [] + sum ys

Hipotese de induçao:
sum (xs ++ ys) = sum xs ++ sum ys


