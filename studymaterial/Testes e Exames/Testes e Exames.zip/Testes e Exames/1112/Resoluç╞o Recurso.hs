{-
exercicio 1
a) tail (head [[1,2],[3,4]]) = [2]
b) map (`mod`2) [1,2,3] = [1,0,1]
c) length (filter (/='a') "banana") = 3
d) head [n | n<-[1..], n*n>20] = 5
e) [x | x<-"ab", n<-[1,2,3]] = "aaabbb"
f) foldr (\x y->x:'.':y) "" "ABC" = A.B.C.
g) ([1,2,3], "banana") = ([Int], [Char]) ou ([Int], String)
h) all f [] = True
   all f (x:xs) = f x && all f xs --- (a->Bool) -> [a] -> Bool

-}

--exercicio 2
prefixo :: String -> String -> Bool
prefixo [] ys = True
prefixo (x:xs) [] = False
prefixo (x:xs) (y:ys) = x==y && prefixo xs ys

--ou
prefixo' :: String -> String -> Bool
prefixo' xs ys = take (length xs) ys ==  xs

--exercicio 3
type Mat = [Vec]
type Vec = [Double]

somaV :: Vec -> Vec -> Vec
somaV [] [] = []
somaV (x:xs) (y:ys) | (length (x:xs)) /= (length (y:ys)) = error "erro"
	                | otherwise = (x+y) : somaV xs ys

somaM :: Mat -> Mat -> Mat
somaM [] [] = []
somaM (xs:xss) (ys:yss) | (length (xs:xss)) /= (length (ys:yss)) = error "erro"
	                    | otherwise = somaV xs ys : somaM xss yss

--exercicio 4
data Arv a = Vazia | No a (Arv a) (Arv a)
tamanho :: Arv a -> Int
tamanho Vazia = 0
tamanho (No x esq dir) = 1 + tamanho esq + tamanho dir

altura :: Arv a -> Int 
altura Vazia = 0
altura (No x esq dir) = 1 + max (altura esq) (altura dir)

--b)
{-
A afirmaçao e falsa pq se t1 e t2:

t1 = No 'a' (No 'b' Vazia Vazia) (No 'c' Vazia Vazia)
t2 = No 'a' (No 'b' Vazia Vazia) Vazia

então temos alturas iguais (2)

altura t1 
= 1 + max (altura (No 'b' Vazia Vazia)) (altura (No 'c' Vazia Vazia)
= 1 + max 1 1
= 2

altura t2 
= 1 + max (altura (No 'b' Vazia Vazia)) (altura Vazia)
= 1 + max 1 0
= 2

mas tamanhos diferentes (3!=2)

tamanho t1 
= 1 + tamanho (No 'b' Vazia Vazia) + tamanho (No 'c' Vazia Vazia)
= 1 + 1 + 1
= 3

tamanho t2
= 1 + tamanho (No 'b' Vazia Vazia) + tamanho Vazia
= 1 + 1 + 0
= 2
-}

--exercicio 5
{-
Provar que : length (xs++ys) = length xs + length ys

length [] = 0
length (x:xs) = 1 + length xs

[] ++ ys = ys
(x:xs) ++ ys = x : (xs++ys)


Caso base:
length ([]++ys) = length ys = 0 + length ys = length [] + length ys.

Passo indutivo:

Hip.indução: length (xs++ys) = length xs + length ys
Tese:        length ((x:xs)++ys) = length (x:xs) + length ys


lado esquerdo da tese:

length ((x:xs)++ys) = length (x:(xs++ys)) = 1 + length (xs++ys) = 1 + (length xs + length ys) 
= (1 + length xs) + length ys
= length (x:xs) + length ys.

Obtemos o lado direito da tese, o que conclui a prova
por indução. -}
