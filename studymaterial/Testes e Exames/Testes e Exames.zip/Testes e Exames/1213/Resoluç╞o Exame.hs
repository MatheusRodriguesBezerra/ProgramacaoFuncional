{-
Exercicio 1 
a) tail (reverse [1,2,3]) = [2,1]
b) filter (/='a') "abba" = "bb"
c) [(x,y) | (x,y)<-[(1,2),(2,3)], x*y==6]] = [(2,3)]
d) head (zip [1..10] (tail [1..10])) = (1,2)
e) foldr (+) 7 [1,2,3] = 13
f) tipo - head [[1],[2,3],[4,5,6]] = [[Int]] -> [Int]
g) tipo - map (>0) = (Num a, Ord a) => [a] -> [Bool]
h) tipo - last = [a] -> a
-}

--Exercicio 2
maximun :: Ord a => [a] -> a
maximun [x] = x 
maximun (x:xs) | x > (maximun xs) = x 
	           | otherwise = maximun xs


maxpos :: [Int] -> Int
maxpos [] = 0
maxpos (x:xs) | x>= maximun (x:xs) = x
	          | otherwise = maxpos xs


--ou 
maxpos' :: [Int] -> Int
maxpos' (x:xs) = foldr max x xs

--ou
maxpos1 :: [Int] -> Int
maxpos1 [] = 0
maxpos1 [x] = x
maxpos1 list | maximum list <=0 = 0
             | otherwise = maximum list


--Exercicio 3

dups:: [a] -> [a]
dups [] = []
dups (x:[]) = [x,x]
dups (x:y:xs) = x:x:y:dups xs





