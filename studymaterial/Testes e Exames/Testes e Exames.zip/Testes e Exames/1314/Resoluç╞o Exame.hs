{-exercicio 1 
a) head ([1,2]:[3,4]:[5]:[]) = [1,2]
b) reverse (take 4 [1,3..]) = [7,5,3,1]
c) [x | x<-[1..10], x*x<10] = [1,2,3]
d) length [x+y | x<-[1,2], y<-[3,4]] = 4
e) filter (>'b') "abacadabra" = "cdr"
f) zip [2..] "abc" = [(2,'a'),(3,'b'),(4,'c')]
g) foldr (\x y->2*x+y) 0 [1,2,3] = 12  
h) [(1,1), (2,2), (3,3)] = [(Int,Int)]
i) [reverse, tail, take 5] = [[a] -> [a]]
-}
--j) 
f :: Num a => [a] -> [a]
f [] = []
f (x:xs) = x : (x+1) : f xs  

--exercicio 2

vogal x = x `elem` "aeiou"

transforma :: String -> String
transforma [] = []
transforma (x:xs) | vogal x = x:'p':x:transforma xs
                  | otherwise = x:transforma xs

{- ou 
transforma' :: String -> String
transforma' = concat . map (\x -> if vogal x then [x,'p',x] else [x])

-}

--exercicio 3
subidas :: [Float] -> Int
subidas [] = 0
subidas [_] = 0
subidas (x1:x2:xs) = (if x1<x2 then 1 else 0) + subidas(x2:xs)


{- ou
subidas :: [Float] -> Int
subidas xs = length (filter (<0) diffs)
             where diffs = zipWith (-) xs (tail xs)
-}

--exercicio 4 
--a)
data Arv a = F | N a (Arv a) (Arv a)

valor :: Arv Int -> Int
valor F = 0
valor (N h _ _) = h

alturas :: Arv a -> Arv Int
alturas F = F 
alturas (N x esq dir) = N h esq' dir'
               where esq' = alturas esq
                     dir' = alturas dir 
                     h = 1 + max (valor esq') (valor dir')

listar :: Arv a -> [a]
listar F = [ ]
listar ( N x esq dir) = [x] ++ listar esq ++ listar dir

--b)
comparar :: Arv Int -> Bool
comparar F = True
comparar (N _ esq dir) = abs (valor esq - valor dir) <=1 && comparar esq && comparar dir

equilibrada :: Arv a -> Bool
equilibrada = comparar . alturas

--exercicio 5 
{- 
take 0 xs = []
take n [] | n>0 = []
take n (x:xs) | n>0 = x : take (n-1) xs 

drop 0 xs = xs
drop n [] | n>0 = []
drop n (x:xs) | n>0 = drop (n-1) xs 


take m ( drop n xs) = drop n ( take (m + n) xs)
Caso base: n=0   
take m (drop 0 xs) = drop 0 (take (m+0) xs)

lado esquerdo:
drop 0 xs = xs 
take m xs

lado direito: 
drop 0 (take m xs) = take m xs -- prova do caso base


Hipotese de induçao: 
take m (drop n xs) = drop n (take (m+n) xs)
Tese de induçao:
take m (drop (n+1) xs) = drop (n+1) (take (m+n+1) xs)

Se xs=[]

lado esquerdo:
take m (drop (n+1) []) = take m [] = []

lado direito:
drop (n+1) (take (m+n+1) []) = drop (n+1) [] = []

Os dois lados são iguais logo a tese de indução é válida neste caso.


Se xs = x:xs'

lado esquerdo:
take m (drop (n+1) (x:xs')) = take m (drop n xs) = drop n (take (m+n) xs')

lado direito:
drop (n+1) (take (m+n+1) (x:xs')) = drop(n+1) (x:take (m+n) xs') = drop n (take (m+n) xs')

De novo obtemos a mesma expressão.
Isto verifica a tese de indução também neste caso e conclui a prova.


drop n- retira os n primeiros membros  drop 3 [1,2,3,4] = [4]
take m- mostra os m primeiros membros  take 3 [1,2,3,4] = [1,2,3] -}
