{-
exercicio 1
a) drop 4 [1,3,4,5,6,9] = [6,9]
b) "abc":[[ ]] ++ "dce":[ ] = ["abc", "", "dce"]
c) length ([’a’,’b’]:[]:[’3’,’a’]:[’b’]:[]) = 4
d) zipWith (+) [0,2..] [1,3..10] = [1,5,9,13,17]
e) map (>5) [2,4..10] = [False, False, True, True, True]
f) foldr (==) False [True,False,True] = True
g) [2,-3,4,-5,6,-7,8,-9,10,-11] = [((-1)^x) * x | x<-[2..11]]
h) (Num a, Ord a) => [a] -> [a]
-}


uns :: [a] -> [Int] 
uns [] = []
uns (x:xs) = 1: uns xs

maiores :: [Int] -> Bool
maiores [] = True
maiores [_] = True
maiores (x1:x2:xs) = x1<x2 && maiores (x2:xs)

maiores1 :: [Int] -> Bool
maiores1 (x:y:xs) = if (until (\(x,y) -> x>=y) (\(x,y,xs) -> ()) (x,y,xs)) == (x:y:xs) !! (length xs -1) then False




