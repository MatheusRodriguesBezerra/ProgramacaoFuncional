--1.
--a) [2,3,1,4,4]
--b) [0,5,10,20,30,40]
--c) tail [[1,2],[], [3,4],[5]] = [[], [3,4],[5]]
--d) 5
--e) [1,1,1,1,1,1]
--f) [(1,4),(2,3),(3,2)]
--g) [2^x| x <- [0..6]]
--h) 0
--i) Num a => [(Bool, a)]
--j) troca :: (a,b) -> (b,a)
--k) g :: Int -> Int -> Int
--l) [([Int],Int)] -> Int


--2.
--a) 
ttriangulo :: Int -> Int -> Int -> String
ttriangulo x y z | (x==y) && (y==z) = "Equilatero"
                 | (x==y) || (x==z) || (y==z) = "Isosceles"
                 | otherwise = "Escaleno"


--b)
rectangulo :: Int -> Int -> Int -> Bool
rectangulo x y z | (x^2) == (y^2) + (z^2) || (y^2) == (x^2) + (z^2) || (z^2) == (x^2) + (y^2) = True
                 | otherwise = False



--3.
maiores :: [Int] -> [Int]
maiores [] = []
maiores [x] = []
maiores (x:y:ys) | (x>y) = x:maiores(y:ys)
                 | otherwise = maiores(y:ys)



--4.
--a)
somapares :: [(Int,Int)] -> [Int]
somapares [] = []
somapares ((x,y):xs) = (x+y):somapares xs

--b)
somapares1 :: [(Int,Int)] -> [Int]
somapares1 [] = []
somapares1 xs = [x+y | (x,y) <- xs]



--5.
--a)
itera :: Int -> (Int -> Int) -> Int -> Int
itera 1 f c = f c
itera n f c = f(itera (n-1) f c)

--ou

itera1 :: Int -> (a -> a) -> a -> a
itera1 n f v | n==0 = v
             | n==1 = f v
             | otherwise = f (itera1 (n-1) f v)


--b)
mult :: Int -> Int -> Int
mult x y = itera 1(*y) x 











