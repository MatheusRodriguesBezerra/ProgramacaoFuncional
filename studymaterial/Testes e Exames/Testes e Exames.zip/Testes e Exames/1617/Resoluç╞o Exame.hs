{-
exercicio 1 
a. tail ([1,2]:[]:[[5,2]]) = [[1,2]:[]:[5,2]] = [[],[5,2]]
b. take 4 [1,4..] = [1,4,7,10]
c. (length.concat) [[1,2,3,4],[5,6,7,8],[2,3,4]] = 11
d. filter (\x -> x‘mod‘3 ==0) [0..9] = [0,3,6,9]
e. foldr (:) [2] [1,3..7] = [1,3,5,7,2]
f. [(x,y) | x <- [1..4], y <- [x..4], x+y == 4] = [(1,3),(2,2)]
g. [1,4,7,10,13,16,19,22,25,28,31] = [x+1 | x<-[0,3..30]]
-}

--h. f [3,2,1] = (2+3)*f[2,1] = 5*(2+2)*f[1]= 5*4*3=20*4= 60
f :: [Int] -> Int
f (x:xs) = (2+x) * f xs
f [x] = 3+x
f [] = 1

--i. f x = x!!3 -- [Int] -> Int
--j. [[Int] -> Int]
--k. N -> Int
--l. (\x -> map (>x)) = Ord a => a -> [a] -> [Bool]

--exercicio 2
--a)
--recursao:
maioresQ :: Ord a => [a] -> a -> [a] 
maioresQ [] n = []
maioresQ (x:xs) n | x>n = x: maioresQ xs n 
	              | otherwise= maioresQ xs n

--sem recursao
maioresQ' :: Ord a => [a]-> a -> [a]
maioresQ' l n = filter (>n) l	              

--ou
maioresQ'' :: Ord a => [a] -> a -> [a]
maioresQ'' l n = [y | y<-l, y>x]

--b)
tamanhoS :: [String] -> [Int]
tamanhoS x = map(length) x
--ou [length l | l<-x]

--exercicio 3
--a)
timesMat :: [[Int]] -> [[Int]] -> [[Int]]
timesMat l1 l2 = [[ if any (==1) (zipWith (*) l1!!l (map (!!c)l2)) then 1 else 0 | c<-[0..n], l<-[0..n]]
	           where n = length l1 -1
--b)
transitiva :: [[Int]] -> Bool
transitiva l = menor (timesMat l l) length  
	           where menor l1 l2 = and [l1!!x!!y <= l2!!x!!y | x<-[0..length l1-1, y<-[0..length l2-1]]

--exercicio 4
tabuada :: Int -> IO ()
tabuada =  do n <-getLine
	        sequence [putStrln (show(x * read n)) | x<-[0..10]]

--exercicio 5
--[0,1,3,6,10,15,21,28,36,45,...] = [sum [0..x] | x<-[0..]] ou 0:zipWith (+) [1..] inff

--exercicio 6
data Arv a = Vazia | No a (Arv a) (Arv a) deriving Show
listar :: Arv a -> [a]
listar Vazia = []
listar (No x esq dir) = listar esq ++ [x] ++ listar dir

simetrica :: Arv a -> Arv a 
simetrica Vazia = Vazia
simetrica (No x esq dir) = No x (simetrica dir) (simetrica esq)

