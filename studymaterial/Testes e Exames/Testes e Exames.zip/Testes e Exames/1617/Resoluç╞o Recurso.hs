--EXAME RECURSO 2017

--1.
--a) length ([1,2]:[3]:[5]:[[]]) = lenght ([[1,2],[3],[5],[]]) = 4
--b) head ([]:[3]:[[5,2]]) = head ([[],[3],[5,2]]) = []
--c) ((2+).(5*)) 4 = 5*4 + 2 = 22
--d) map (<8) [2,4..10] = [True,True,True,Flase,False]
--e) foldl (\x y -> 2*x + y) 0 [1,1,0,1,0] = 26
--f) [(x,y) | x <- [1..4], y <- [1..x], x == y+1] = [(2,1),(3,2),(4,3)]
--g) [(2*x +1, 2^x *2) | x <- [0..]]
--h) func [x] = [3*x]
--   func (x:xs) = (2*x) : func xs
--   func [1,2,1,5,4] = [2,4,2,10,12]
--i) [(2>),(==4)] :: [Int -> Bool]
--j) (1+).(*3) :: ?
--k) f :: Arv -> Int
--   f(Folha a) = a
--   f(No esq dir) = f dir
--   data Arv = Folha | No (Arv) (Arv)
--l) f xs ys = sum(zipWith (*) xs ys) :: Num a => [a] -> [a] -> Int



--2.
--a)
nafrente :: a -> [[a]] -> [[a]]
nafrente c xs = map (c:) xs

--b)
ocorreN :: Eq a => a -> [a] -> Int -> Bool
ocorreN x l n = length (filter (==x) l) == n



--3.
--a)
subs :: [a] -> [[a]]
subs [] = [[]]
subs (x:xs) = map (x:) sxs ++ sxs
            where sxs = subs xs

--b)
subsAsc :: Ord a => [a] -> [[a]]
subsAsc [] = [[]]
subsAsc (x:xs) = [x:l | l <- sxs, null l || x < head l] ++ sxs
               where sxs = subsAsc xs 


--4.
soma :: Int -> IO()
soma k = do {
            x <- getLine;
            let y = read x in
            if (y == 0) then
            putStrLn (show k);
            else soma (k + y);
         }
soma t = soma 0


{- Resolução da professora (não funciona)
soma :: IO()
soma = soma_aux 0
     where soma_aux n = do x <- getLine
                        let y = read x in
                        if y == 0 then
                        do putStrLn (show n)
                        return ()
                        else soma_aux (n+y)


-}

--5.
--a)
data (ArvT a) = Folha a | No (ArvT a) (ArvT a) (ArvT a)
arv :: ArvT Int
arv = No (Folha 1) (No(Folha 4)(Folha 5)(Folha 8)) (Folha 9)


--b)
nelementos :: ArvT a -> Int 
nelementos (Folha _) = 1
nelementos (No esq cnt dir) = nelementos esq + nelementos cnt + nelementos dir


--c)
mapTree :: (a -> b) -> (ArvT a) -> (ArvT b) 
mapTree f (Folha x) = Folha (f x)
mapTree f (No e c d) = No(mapTree f e)(mapTree f c)(mapTree f d)


--6)
scanl' :: (a -> b -> b) -> b -> [a] -> [b]
scanl' f v xs = v:zipWith f xs (scanl' f v xs)


---------------------------------------------------------------------------
--Epoca normal 2018

aprov :: [Int] -> [Char]
aprov l = [if x >= 15 then 'A' else 'R' | x <- l]

injust :: [Int] -> Int
injust (x:xs) = length(filter (\x -> x>9 && x<15)xs)

injust' :: [Int] -> Int
injust' (x:xs) = length(filter(<15) (filter(>10)xs))

repete :: a -> [[a]]
repete x = [] : map (x:) (repete x)

{-maximo :: IO()
maximo = maximo_aux 0
maximo_aux :: Int -> IO()
maximo_aux n = do x <- getLine
                          let y = read x in
                          if y == 0 then print n
                          else calc (max y n)-}

























