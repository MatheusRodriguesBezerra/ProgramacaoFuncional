--1
--a [1,5,4,3]
--b [5,6,9]
--c head[2,3,1,4,4,6] = 2
--d [15,18,21,24,27,30}]
--e 4
--f [1,2,3,4,6,9]
--g [1,2,3]
--h [((-1)^x)*x | x<-[0..10]] ou [-x | x<- [o,1,-2,3,-4,5,-6,7-8,9,-10]
--i 8
--j ([Char],[Float])
--k >fst :: (a,b) -> a
--l Int -> Int -> Int -> Bool
--m [a] -> a


--2
numEqual :: Int -> Int -> Int -> Int
numEqual n m p | n==m && m==p = 3
               | n==m && m/=p = 2
               | n/=m && m==p = 2
               | p/=m && n==p = 2
               | otherwise = 1

numEqual' n m p | n==m && m==p = 3
                | n/=m && n/=p && m/=p = 1
                | otherwise = 2


--3
area :: Float -> Float -> Float -> Float -> Float -> Float -> Float
area a b c d p q = 0.25*sqrt(s)
                 where s = 4*(p^2)*(q^2)-((b^2)+(d^2)-(a^2)-(c^2))^2



--4
enquantoPar :: [Int] -> [Int]
enquantoPar [] = []
enquantoPar (x:xs) = if x `mod` 2 == 0 then x:enquantoPar xs else []
               
          

--5
nat_zip :: [a] -> [(Int,a)]
nat_zip xs = zip [1..] xs



--6
--a)
quadrados :: [Int] -> [Int]
quadrados [] = []
quadrados (x:xs) = (x^2):quadrados xs


--b)
quadradosb :: [Int] -> [Int]
quadradosb [] = []
quadradosb xs = [x*x| x <- xs]





enquantospar :: [Int] -> [Int]
enquantospar [] = []
enquantospar (x:xs) | x `mod` 2 == 0 = x:enquantospar xs
                    | otherwise = []














